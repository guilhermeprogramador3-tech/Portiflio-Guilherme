# Corrida da Montanha

Jogo de gincana escolar para telão, executado diretamente no navegador sem dependências externas. A renderização usa um canvas quadrado de 1024×1024 e compõe o cenário em três camadas: céu e montanhas distantes, chão jogável em perspectiva e foreground transparente para oclusão.

## Como jogar

Ao abrir `index.html`, a tela inicial exibe o título **A Grande Subida - Gincana Escolar**. Clique em **Jogar em Tela Cheia** ou pressione `F` para ativar a API `requestFullscreen()` e iniciar a cutscene de rivalidade. A abertura dura 10 segundos em quatro atos cinematográficos: abertura lenta de 0–3s, apresentação em câmera lenta de 3–6s, confronto de 6–8s e partida de 8–10s. Os nove quadros recebem tweening contínuo de zoom, pan, rotação, mistura entre frames, tremor, partículas, flash e fade antes de liberar os controles.

Depois da cutscene, o professor usa uma tecla dedicada por personagem: **A ou 1** move o Esqueleto da sala 2A, **B ou 2** move o Fantasma da sala 2B e **C ou 3** move o Slime da sala 2C. Uma única pressão avança apenas aquele competidor um passo e atualiza imediatamente o mini placar no canto superior esquerdo. A rota tem 100 passos contínuos; a cada cinco passos há uma bandeira visual no caminho. As bandeiras inativas são discretas e ficam coloridas quando uma ou mais salas chegam a elas. Cada avanço dispara um pulo; quando uma sala alcança o passo 100, a corrida é encerrada e começa a cerimônia de premiação.

`F` alterna tela cheia, `R` reinicia todos no passo zero, `Z` desfaz o último movimento concluído e `Espaço` pausa/despausa a corrida. A única interface durante a partida é o mini placar discreto: ele mostra 2A, 2B e 2C com os pontos formatados de 00 a 100. Não há barras de progresso nem outros elementos de HUD. Na cerimônia, o ranking é ordenado pelos pontos das três salas; os personagens caminham para o pódio, recebem troféus de ouro, prata e bronze, e a tela mostra fogos, confetes e a instrução para pressionar `R`.

O deslocamento entre passos usa uma spline Catmull–Rom pré-amostrada e parametrizada por comprimento de arco. Assim, as curvas do zigue-zague são arredondadas, a velocidade é independente da taxa de quadros e a função `easeInOutSine` controla a aceleração e a frenagem de cada avanço. A tangente da spline atualiza a direção visual do personagem e a posição retornada continua alimentando o Y-sorting, a escala de perspectiva e a sombra ancorada nos pés.

Nos passos 1–50, o mundo recebe um acompanhamento de câmera suavizado pelo líder, com zoom out quando a diferença entre os competidores ultrapassa dez passos e tremor curto a cada pulo. A escala nessa primeira metade vai gradualmente de 1.0× a aproximadamente 0.8×, enquanto os quatro frames de caminhada são avançados por distância percorrida, mantendo o ciclo sincronizado com o deslocamento.

A tecla `R` reinicia a partida para o operador do telão, sem criar elemento de interface no palco.

## Estrutura

- `index.html`: marcação mínima e canvas.
- `style.css`: tela cheia, sem rolagem e com renderização pixelada.
- `script.js`: composição das camadas, rota, escala perspectiva, sombras, mini placar, badges, entrada, estados, partículas e Y-sorting.
- `assets/background.png`: céu calmo, sol, nuvens e montanhas nevadas distantes, 1024×1024.
- `assets/midground.png`: montanha jogável transparente com um único caminho de terra limpo, textura sutil de chão, degraus/checkpoints e perspectiva larga na base para estreita no topo, 1024×1024.
- `assets/foreground.png`: árvores, arbustos, pedras e folhagens transparentes somente nas bordas e cantos, com corredor central livre para oclusão controlada, 1024×1024.
- `assets/ghost_sheet.png`, `skeleton_sheet.png`, `slime_sheet.png`: folhas transparentes 512×512 em grade 4×4.
- `assets/checkpoint_flags.png`: folha transparente de bandeiras coloridas e combinações de salas.
- `assets/cinematic_rivalry_sheet.png`: storyboard 3×3 da cutscene cinematográfica, com apresentação, confronto e largada.
- `assets/victory_podium.png`: cenário 32-bit da cerimônia com pódio de três níveis.
- `assets/trophy_gold.png`, `trophy_silver.png`, `trophy_bronze.png`: troféus com glow para os três lugares.

Cada folha de sprites usa 16 células de 128×128. A primeira linha contém idle/blink, a segunda caminhada, a terceira pulo e a quarta celebração/reação. As folhas incluem a identificação de sala e sombras de contato; o código também reforça a sombra com escala perspectiva, de 1.0× na base a 0.6× no topo.

Os waypoints do código acompanham a linha central do caminho: `(512,918)`, `(690,836)`, `(350,750)`, `(674,654)`, `(396,558)`, `(646,462)`, `(370,368)`, `(612,274)` e `(500,148)`. O renderizador calcula `depth = footY`, ordena os atores por esse valor e aplica `scale = 0.6 + 0.4 * depthRatio`, onde `depthRatio` vai de 0 no topo a 1 na base. A sombra usa o mesmo fator de escala, fica ancorada em `footY` e reduz sua opacidade conforme o personagem sobe. A ordem visual é background, midground, atores depth-sorted e foreground.

A versão atual também aplica uma névoa atmosférica muito sutil sobre o midground para separar o topo distante da área jogável, blend entre quadros da cutscene para reduzir cortes secos e faíscas animadas no momento de rivalidade. Durante a corrida, o cenário recebe movimento contínuo por `requestAnimationFrame`: scroll horizontal suave do background, parallax de montanhas, raios de sol pulsantes, shimmer de chão, sway do foreground e partículas ambientais de vaga-lumes, folhas e poeira dourada. Os efeitos usam arrays pequenos e atualizações leves para preservar a fluidez. Essas melhorias mantêm o mini placar discreto, os controles, os 100 passos e as bandeiras.
