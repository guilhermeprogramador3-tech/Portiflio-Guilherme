(() => {
  'use strict';

  const DESIGN_SIZE = 1024;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.imageSmoothingEnabled = false;
  const startScreen = document.getElementById('start-screen');
  const startButton = document.getElementById('start-button');
  const ceremonyStatus = document.getElementById('ceremony-status');

  const ASSET_PATH = 'assets/';
  const assets = {
    background: 'background.png',
    midground: 'midground.png',
    foreground: 'foreground.png',
    flags: 'checkpoint_flags.png',
    podium: 'victory_podium.png',
    trophyGold: 'trophy_gold.png',
    trophySilver: 'trophy_silver.png',
    trophyBronze: 'trophy_bronze.png',
    cutscene: 'cinematic_rivalry_sheet.png',
    ghost: 'ghost_sheet.png',
    skeleton: 'skeleton_sheet.png',
    slime: 'slime_sheet.png'
  };

  const imageCache = new Map();
  const elapsed = (start, now) => Math.max(0, now - start);
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeInOut = (t) => t * t * (3 - 2 * t);
  const easeInOutQuad = (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  const easeInOutSine = (t) => -(Math.cos(Math.PI * clamp(t, 0, 1)) - 1) / 2;
  const easeOutBack = (t) => {
    const c1 = 1.70158;
    const c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  };
  const BASE_Y = 918;
  const TOP_Y = 148;
  const TOTAL_STEPS = 100;
  const FLAG_INTERVAL = 5;

  // Center line for the single playable zig-zag route. Lower checkpoints are wider.
  const checkpoints = [
    { x: 512, y: 918 },
    { x: 690, y: 836 },
    { x: 350, y: 750 },
    { x: 674, y: 654 },
    { x: 396, y: 558 },
    { x: 646, y: 462 },
    { x: 370, y: 368 },
    { x: 612, y: 274 },
    { x: 500, y: 148 }
  ];

  const players = [
    { id: 'skeleton', keys: ['KeyA', 'Digit1'], sheet: 'skeleton', room: '2A', lane: 0, tint: '#4b9cff', checkpoint: 0, step: 0, moving: null, queuedMoves: 0, celebrationUntil: 0, reactionUntil: 0 },
    { id: 'ghost', keys: ['KeyB', 'Digit2'], sheet: 'ghost', room: '2B', lane: -72, tint: '#ef6262', checkpoint: 0, step: 0, moving: null, queuedMoves: 0, celebrationUntil: 0, reactionUntil: 0 },
    { id: 'slime', keys: ['KeyC', 'Digit3'], sheet: 'slime', room: '2C', lane: 72, tint: '#69d66b', checkpoint: 0, step: 0, moving: null, queuedMoves: 0, celebrationUntil: 0, reactionUntil: 0 }
  ];

  // One direct key per racer. A single press advances only that character.
  const keyToPlayer = Object.fromEntries(players.flatMap((player) => player.keys.map((key) => [key, player])));

  const particles = [];
  const ceremonyParticles = [];
  const ambientParticles = [];
  let lastTime = 0;
  let winner = null;
  let ready = false;
  let loadedAssets = {};
  let phase = 'start';
  let cutsceneStartedAt = 0;
  let paused = false;
  const moveHistory = [];
  const CUTSCENE_DURATION = 10000;
  let cutsceneAudio = null;
  let cutsceneAudioTimers = [];
  let ceremonyAudio = null;
  let pontos_2A = 0;
  let pontos_2B = 0;
  let pontos_2C = 0;
  let ceremonyStartedAt = 0;
  let ceremonyOrder = [];
  const CEREMONY_DURATION = 10000;
  const camera = { x: 0, y: 0, zoom: 1, shake: 0 };

  function updateRaceCamera(dt) {
    const raceStep = (player) => player.step + (player.moving ? player.moving.ease : 0);
    const leader = players.reduce((best, player) => raceStep(player) > raceStep(best) ? player : best, players[0]);
    const leaderStep = raceStep(leader);
    const leaderProgress = clamp(leaderStep / 50, 0, 1);
    const leaderPoint = currentPosition(leader);
    const spread = Math.max(...players.map(raceStep)) - Math.min(...players.map(raceStep));
    const targetX = leaderStep <= 50 ? clamp((leaderPoint.x - DESIGN_SIZE / 2) * 0.2, -86, 86) : 0;
    const targetZoom = leaderStep <= 50 && spread > 10 ? 0.96 : leaderStep <= 50 ? 1.08 : 1;
    const targetY = leaderStep <= 50 && targetZoom > 1 ? leaderProgress * 70 : 0;
    const smoothing = 1 - Math.exp(-dt * 7);
    camera.x = lerp(camera.x, targetX, smoothing);
    camera.y = lerp(camera.y, targetY, smoothing);
    camera.zoom = lerp(camera.zoom, targetZoom, smoothing);
    camera.shake = Math.max(0, camera.shake - dt * 70);
  }

  function cameraTransform(now) {
    const shakeX = camera.shake ? Math.sin(now * 0.11) * camera.shake : 0;
    const shakeY = camera.shake ? Math.cos(now * 0.13) * camera.shake * 0.55 : 0;
    ctx.translate(DESIGN_SIZE / 2 + shakeX, DESIGN_SIZE / 2 + shakeY);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-DESIGN_SIZE / 2 - camera.x, -DESIGN_SIZE / 2 - camera.y);
  }

  function setRoomScore(player, value) {
    const score = clamp(value, 0, TOTAL_STEPS);
    if (player.room === '2A') pontos_2A = score;
    if (player.room === '2B') pontos_2B = score;
    if (player.room === '2C') pontos_2C = score;
  }

  function initAmbientParticles() {
    if (ambientParticles.length) return;
    for (let i = 0; i < 42; i += 1) ambientParticles.push({ type: 'firefly', x: Math.random() * DESIGN_SIZE, y: 140 + Math.random() * 760, phase: Math.random() * Math.PI * 2, speed: 0.15 + Math.random() * 0.35, size: 2 + Math.random() * 2, color: Math.random() > 0.5 ? '#ffe879' : '#b9f27b' });
    for (let i = 0; i < 24; i += 1) ambientParticles.push({ type: 'leaf', x: Math.random() * DESIGN_SIZE, y: Math.random() * DESIGN_SIZE, phase: Math.random() * Math.PI * 2, speed: 0.12 + Math.random() * 0.25, size: 3 + Math.random() * 3, color: Math.random() > 0.5 ? '#d39b4a' : '#8fae52' });
    for (let i = 0; i < 34; i += 1) ambientParticles.push({ type: 'dust', x: Math.random() * DESIGN_SIZE, y: 160 + Math.random() * 780, phase: Math.random() * Math.PI * 2, speed: 0.08 + Math.random() * 0.18, size: 1 + Math.random() * 1.5, color: '#ffe7a0' });
  }

  function updateAmbientParticles(dt) {
    initAmbientParticles();
    ambientParticles.forEach((particle) => {
      particle.phase += dt * particle.speed;
      if (particle.type === 'firefly') {
        particle.x += Math.sin(particle.phase * 1.7) * dt * 7;
        particle.y -= dt * (2 + particle.speed * 5);
        if (particle.y < 110) particle.y = DESIGN_SIZE - 40;
      } else if (particle.type === 'leaf') {
        particle.x += Math.sin(particle.phase) * dt * 18;
        particle.y += dt * (14 + particle.speed * 18);
        if (particle.y > DESIGN_SIZE + 12) { particle.y = -12; particle.x = Math.random() * DESIGN_SIZE; }
      } else {
        particle.x += Math.sin(particle.phase * 1.4) * dt * 6;
        particle.y -= dt * (3 + particle.speed * 7);
        if (particle.y < 120) particle.y = DESIGN_SIZE - 30;
      }
      particle.x = (particle.x + DESIGN_SIZE) % DESIGN_SIZE;
    });
  }

  function loadImage(filename) {
    if (imageCache.has(filename)) return imageCache.get(filename);
    const image = new Image();
    const promise = new Promise((resolve, reject) => {
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error(`Não foi possível carregar ${filename}`));
    });
    image.src = ASSET_PATH + filename;
    imageCache.set(filename, promise);
    return promise;
  }

  async function loadAssets() {
    const loaded = await Promise.all(Object.entries(assets).map(async ([key, filename]) => [key, await loadImage(filename)]));
    return Object.fromEntries(loaded);
  }

  const ROUTE_SAMPLES = 800;
  const MOVE_SPEED = 80;

  function catmullRomPoint(t) {
    const scaled = clamp(t, 0, 1) * (checkpoints.length - 1);
    const index = Math.min(checkpoints.length - 2, Math.floor(scaled));
    const local = scaled - index;
    const p0 = checkpoints[Math.max(0, index - 1)];
    const p1 = checkpoints[index];
    const p2 = checkpoints[index + 1];
    const p3 = checkpoints[Math.min(checkpoints.length - 1, index + 2)];
    const local2 = local * local;
    const local3 = local2 * local;
    return {
      x: 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * local + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * local2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * local3),
      y: 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * local + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * local2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * local3)
    };
  }

  const routeArc = (() => {
    const samples = [];
    let total = 0;
    let previous = catmullRomPoint(0);
    samples.push({ t: 0, distance: 0 });
    for (let i = 1; i <= ROUTE_SAMPLES; i += 1) {
      const t = i / ROUTE_SAMPLES;
      const point = catmullRomPoint(t);
      total += Math.hypot(point.x - previous.x, point.y - previous.y);
      samples.push({ t, distance: total });
      previous = point;
    }
    return { samples, total };
  })();

  function arcProgressToSplineT(progress) {
    const target = clamp(progress, 0, 1) * routeArc.total;
    let low = 0;
    let high = routeArc.samples.length - 1;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      if (routeArc.samples[middle].distance < target) low = middle + 1;
      else high = middle;
    }
    const next = routeArc.samples[low];
    const previous = routeArc.samples[Math.max(0, low - 1)];
    const span = next.distance - previous.distance || 1;
    return lerp(previous.t, next.t, clamp((target - previous.distance) / span, 0, 1));
  }

  function routePoint(progress, lane = 0) {
    const t = arcProgressToSplineT(progress);
    const point = catmullRomPoint(t);
    const ahead = catmullRomPoint(clamp(t + 0.0015, 0, 1));
    const dx = ahead.x - point.x;
    const dy = ahead.y - point.y;
    const length = Math.hypot(dx, dy) || 1;
    return {
      x: point.x - (dy / length) * lane,
      y: point.y + (dx / length) * lane,
      tangentX: dx / length,
      tangentY: dy / length
    };
  }

  function currentPosition(player) {
    const progress = player.moving
      ? lerp(player.moving.fromStep / TOTAL_STEPS, player.moving.toStep / TOTAL_STEPS, player.moving.ease)
      : player.step / TOTAL_STEPS;
    const point = routePoint(progress, player.lane);
    return { ...point, progress, depth: point.y };
  }

  // 2.5D perspective: scale is driven by the character's foot depth.
  function depthRatio(y) {
    return clamp((y - TOP_Y) / (BASE_Y - TOP_Y), 0, 1);
  }

  function perspectiveScale(y) {
    return 0.6 + (0.4 * depthRatio(y));
  }

  function racePerspectiveScale(point) {
    if (point.progress <= 0.5) return lerp(1, 0.8, point.progress / 0.5);
    return lerp(0.8, 0.6, (point.progress - 0.5) / 0.5);
  }

  function addParticle(x, y, color, count, spread = 1, speed = 1) {
    for (let i = 0; i < count; i += 1) {
      const angle = Math.random() * Math.PI * 2;
      const force = (0.45 + Math.random() * 0.85) * speed;
      particles.push({ x: x + (Math.random() - 0.5) * 22, y: y + (Math.random() - 0.5) * 10, vx: Math.cos(angle) * force * spread, vy: Math.sin(angle) * force * spread - speed * 0.45, life: 0.55 + Math.random() * 0.45, size: 3 + Math.floor(Math.random() * 3), color });
    }
  }

  function startMove(player, now) {
    if (!ready || phase !== 'game' || paused || winner || player.moving) return;
    const from = player.step;
    const to = clamp(from + 1, 0, TOTAL_STEPS);
    if (from === to) return;
    const stepDistance = routeArc.total / TOTAL_STEPS;
    player.moving = { elapsed: 0, duration: Math.max(300, (stepDistance / MOVE_SPEED) * 1000), fromStep: from, toStep: to, ease: 0, walkDistance: 0 };
    player.nextStep = to;
    setRoomScore(player, to);
    const start = currentPosition(player);
    addParticle(start.x, start.y + 16, '#d7aa69', 10, 2.2, 1.7);
    if (from < 50) camera.shake = 7;
  }

  function ceremonyRanking() {
    return [...players].sort((a, b) => b.step - a.step || a.room.localeCompare(b.room));
  }

  function startCeremony(now) {
    if (phase === 'ceremony') return;
    winner = ceremonyRanking()[0];
    ceremonyOrder = ceremonyRanking();
    ceremonyStartedAt = now;
    phase = 'ceremony';
    players.forEach((player) => { player.moving = null; player.queuedMoves = 0; player.celebrationUntil = 0; player.reactionUntil = 0; });
    ceremonyParticles.length = 0;
    if (ceremonyStatus) ceremonyStatus.textContent = `Cerimônia de premiação iniciada. Sala ${winner.room} lidera a classificação.`;
    for (let i = 0; i < 64; i += 1) ceremonyParticles.push({ x: Math.random() * DESIGN_SIZE, y: -Math.random() * 500, vx: (Math.random() - 0.5) * 1.5, vy: 1.2 + Math.random() * 2.2, spin: Math.random() * Math.PI, color: ['#f6d36b', '#ef6262', '#69d66b', '#4b9cff', '#fff2b8'][i % 5], size: 4 + Math.random() * 6 });
    playVictoryFanfarra();
  }

  function playVictoryFanfarra() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    try {
      ceremonyAudio = new AudioContext();
      const now = ceremonyAudio.currentTime;
      const master = ceremonyAudio.createGain();
      master.gain.setValueAtTime(0.0001, now);
      master.gain.linearRampToValueAtTime(0.075, now + 0.15);
      master.gain.exponentialRampToValueAtTime(0.0001, now + 3.2);
      master.connect(ceremonyAudio.destination);
      [261.63, 329.63, 392, 523.25, 659.25].forEach((frequency, index) => {
        const oscillator = ceremonyAudio.createOscillator();
        oscillator.type = index < 2 ? 'triangle' : 'square';
        oscillator.frequency.value = frequency;
        oscillator.connect(master);
        oscillator.start(now + index * 0.13);
        oscillator.stop(now + 1.2 + index * 0.13);
      });
    } catch (error) {
      ceremonyAudio = null;
    }
  }

  function stopCeremonyAudio() {
    if (ceremonyAudio) ceremonyAudio.close().catch(() => {});
    ceremonyAudio = null;
  }

  function completeMove(player, now) {
    const previous = player.step;
    player.step = player.nextStep;
    player.checkpoint = Math.floor(player.step / (TOTAL_STEPS / (checkpoints.length - 1)));
    player.moving = null;
    moveHistory.push({ playerId: player.id, fromStep: previous });
    player.celebrationUntil = now + 2000;
    const point = currentPosition(player);
    addParticle(point.x, point.y - 8, player.tint, 14, 2.3, 1.6);
    players.forEach((other) => {
      if (other !== player && player.step > other.step && previous <= other.step) {
        other.reactionUntil = now + 1100;
      }
    });
    if (player.step >= TOTAL_STEPS) {
      addParticle(point.x, point.y - 18, '#ffe07a', 28, 3.2, 2.3);
      startCeremony(now);
    } else if (player.queuedMoves > 0 && phase === 'game') {
      player.queuedMoves -= 1;
      startMove(player, now);
    }
  }

  function handleKeyDown(event) {
    if (event.code === 'KeyF') {
      event.preventDefault();
      if (phase === 'start') beginPresentation();
      else toggleFullscreen();
      return;
    }
    if (event.code === 'KeyR') {
      event.preventDefault();
      resetGame(phase === 'ceremony');
      return;
    }
    if (event.code === 'KeyZ') {
      event.preventDefault();
      undoLastMove();
      return;
    }
    if (event.code === 'Space') {
      event.preventDefault();
      if (phase === 'game') paused = !paused;
      return;
    }
    const player = keyToPlayer[event.code];
    if (player) {
      event.preventDefault();
      if (player.moving) {
        player.queuedMoves = Math.min(3, player.queuedMoves + 1);
        return;
      }
      startMove(player, performance.now());
    }
  }

  async function requestFullscreen() {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
      try { await document.documentElement.requestFullscreen(); } catch (error) { console.warn('Fullscreen indisponível', error); }
    }
  }

  async function toggleFullscreen() {
    if (document.fullscreenElement) await document.exitFullscreen?.();
    else await requestFullscreen();
  }

  function resetGame(returnToStart = false) {
    stopCutsceneAudio();
    stopCeremonyAudio();
    players.forEach((player) => {
      player.step = 0;
      player.checkpoint = 0;
      player.moving = null;
      player.queuedMoves = 0;
      player.nextStep = 0;
      player.celebrationUntil = 0;
      player.reactionUntil = 0;
      player.depth = BASE_Y;
    });
    moveHistory.length = 0;
    particles.length = 0;
    winner = null;
    pontos_2A = 0;
    pontos_2B = 0;
    pontos_2C = 0;
    paused = false;
    camera.x = 0;
    camera.y = 0;
    camera.zoom = 1;
    camera.shake = 0;
    phase = returnToStart ? 'start' : 'game';
    startScreen.hidden = !returnToStart;
    if (ceremonyStatus) ceremonyStatus.textContent = returnToStart ? 'Gincana reiniciada. Pronto para começar.' : '';
  }

  function undoLastMove() {
    if (phase !== 'game' || moveHistory.length === 0) return;
    const last = moveHistory.pop();
    const player = players.find((item) => item.id === last.playerId);
    if (!player || player.moving) return;
    player.step = last.fromStep;
    setRoomScore(player, player.step);
    player.checkpoint = Math.floor(player.step / (TOTAL_STEPS / (checkpoints.length - 1)));
    player.celebrationUntil = 0;
    player.reactionUntil = 0;
    winner = null;
  }

  function playCutsceneImpact() {
    if (!cutsceneAudio) return;
    const now = cutsceneAudio.currentTime;
    const oscillator = cutsceneAudio.createOscillator();
    const gain = cutsceneAudio.createGain();
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(180, now);
    oscillator.frequency.exponentialRampToValueAtTime(48, now + 0.28);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.22, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
    oscillator.connect(gain).connect(cutsceneAudio.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.34);
  }

  function playCutsceneWhoosh() {
    if (!cutsceneAudio) return;
    const now = cutsceneAudio.currentTime;
    const oscillator = cutsceneAudio.createOscillator();
    const gain = cutsceneAudio.createGain();
    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(240, now);
    oscillator.frequency.exponentialRampToValueAtTime(1200, now + 0.18);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.08, now + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
    oscillator.connect(gain).connect(cutsceneAudio.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.24);
  }

  function startCutsceneAudio() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    try {
      cutsceneAudio = new AudioContext();
      const now = cutsceneAudio.currentTime;
      const master = cutsceneAudio.createGain();
      master.gain.setValueAtTime(0.0001, now);
      master.gain.linearRampToValueAtTime(0.03, now + 2.8);
      master.gain.linearRampToValueAtTime(0.075, now + 7.8);
      master.gain.linearRampToValueAtTime(0.0001, now + CUTSCENE_DURATION / 1000);
      master.connect(cutsceneAudio.destination);
      const drone = cutsceneAudio.createOscillator();
      drone.type = 'sine';
      drone.frequency.setValueAtTime(82, now);
      drone.frequency.linearRampToValueAtTime(196, now + CUTSCENE_DURATION / 1000);
      drone.connect(master);
      drone.start(now);
      drone.stop(now + CUTSCENE_DURATION / 1000 + 0.1);
      cutsceneAudioTimers = [3000, 4200, 5600, 8000].map((delay) => setTimeout(playCutsceneWhoosh, delay));
      cutsceneAudioTimers.push(setTimeout(playCutsceneImpact, 6800));
    } catch (error) {
      cutsceneAudio = null;
    }
  }

  function stopCutsceneAudio() {
    cutsceneAudioTimers.forEach((timer) => clearTimeout(timer));
    cutsceneAudioTimers = [];
    if (cutsceneAudio) {
      cutsceneAudio.close().catch(() => {});
      cutsceneAudio = null;
    }
  }

  function beginPresentation() {
    if (!ready || phase !== 'start') return;
    requestFullscreen();
    phase = 'cutscene';
    cutsceneStartedAt = performance.now();
    startCutsceneAudio();
    startScreen.hidden = true;
  }

  function update(now) {
    const dt = Math.min(0.033, (now - lastTime) / 1000 || 0);
    lastTime = now;
    if (phase === 'cutscene') {
      if (elapsed(cutsceneStartedAt, now) >= CUTSCENE_DURATION) {
        phase = 'game';
        stopCutsceneAudio();
      }
      return;
    }
    if (phase === 'ceremony') {
      updateAmbientParticles(dt);
      ceremonyParticles.forEach((particle) => {
        particle.x += particle.vx * dt * 60 + Math.sin(now * 0.004 + particle.spin) * 0.35;
        particle.y += particle.vy * dt * 60;
        particle.spin += dt * 3;
        if (particle.y > DESIGN_SIZE + 20) { particle.y = -20; particle.x = Math.random() * DESIGN_SIZE; }
      });
      return;
    }
    if (phase !== 'game') return;
    updateAmbientParticles(dt);
    if (paused) return;
    updateRaceCamera(dt);
    players.forEach((player) => {
      if (player.moving) {
        const previousEase = player.moving.ease;
        player.moving.elapsed += dt * 1000;
        player.moving.ease = easeInOutSine(clamp(player.moving.elapsed / player.moving.duration, 0, 1));
        player.moving.walkDistance += Math.abs(player.moving.ease - previousEase) * (routeArc.total / TOTAL_STEPS);
        if (player.moving.elapsed >= player.moving.duration) completeMove(player, now);
      }
    });
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      const particle = particles[i];
      particle.x += particle.vx * dt * 60;
      particle.y += particle.vy * dt * 60;
      particle.vy += 0.055 * dt * 60;
      particle.life -= dt * 1.35;
      if (particle.life <= 0) particles.splice(i, 1);
    }
  }

  function drawLayer(name) {
    const layer = loadedAssets[name];
    if (layer) ctx.drawImage(layer, 0, 0, DESIGN_SIZE, DESIGN_SIZE);
  }

  function drawAnimatedBackground(now) {
    const layer = loadedAssets.background;
    if (!layer) return;
    const cloudOffset = -((now * 0.006) % DESIGN_SIZE);
    const mountainOffset = -((now * 0.0007) % DESIGN_SIZE);
    ctx.save();
    ctx.drawImage(layer, cloudOffset, 0, DESIGN_SIZE, DESIGN_SIZE);
    ctx.drawImage(layer, cloudOffset + DESIGN_SIZE, 0, DESIGN_SIZE, DESIGN_SIZE);
    ctx.globalAlpha = 0.16;
    ctx.drawImage(layer, mountainOffset, 0, DESIGN_SIZE, DESIGN_SIZE);
    ctx.drawImage(layer, mountainOffset + DESIGN_SIZE, 0, DESIGN_SIZE, DESIGN_SIZE);
    ctx.restore();
    const pulse = 0.055 + (Math.sin(now * 0.0012) + 1) * 0.025;
    const rays = ctx.createRadialGradient(830, 176, 18, 830, 176, 430);
    rays.addColorStop(0, `rgba(255, 239, 170, ${pulse * 1.8})`);
    rays.addColorStop(1, 'rgba(255, 239, 170, 0)');
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = rays;
    ctx.fillRect(430, 0, 594, 620);
    ctx.globalAlpha = 0.08 + Math.sin(now * 0.0009) * 0.025;
    ctx.fillStyle = '#ffe9a3';
    ctx.beginPath();
    ctx.moveTo(830, 176);
    ctx.lineTo(570, 610);
    ctx.lineTo(665, 610);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawAnimatedMidground(now) {
    drawLayer('midground');
    const shimmer = (Math.sin(now * 0.003) + 1) * 0.5;
    ctx.save();
    ctx.globalAlpha = 0.045 + shimmer * 0.035;
    ctx.strokeStyle = '#fff0a3';
    ctx.lineWidth = 2;
    for (let i = 0; i < 9; i += 1) {
      const y = 300 + i * 68 + Math.sin(now * 0.0014 + i) * 4;
      ctx.beginPath();
      ctx.moveTo(300 + (i % 2) * 90, y);
      ctx.lineTo(430 + (i % 3) * 80, y - 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawAnimatedForeground(now) {
    const layer = loadedAssets.foreground;
    if (!layer) return;
    const sway = Math.sin(now * 0.0013) * 1.8;
    ctx.save();
    ctx.translate(sway, 0);
    ctx.drawImage(layer, 0, 0, DESIGN_SIZE, DESIGN_SIZE);
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = 0.05 + (Math.sin(now * 0.0018) + 1) * 0.015;
    ctx.fillStyle = '#b9ef9b';
    ctx.fillRect(18, 720, 150, 2);
    ctx.fillRect(850, 690, 150, 2);
    ctx.restore();
  }

  function drawAmbientParticles(now) {
    initAmbientParticles();
    ambientParticles.forEach((particle) => {
      const twinkle = 0.22 + (Math.sin(now * 0.003 + particle.phase * 3) + 1) * 0.32;
      ctx.save();
      ctx.globalAlpha = particle.type === 'leaf' ? 0.48 : twinkle;
      ctx.fillStyle = particle.color;
      if (particle.type === 'leaf') {
        ctx.translate(particle.x, particle.y);
        ctx.rotate(Math.sin(particle.phase) * 0.6);
        ctx.fillRect(-particle.size, -1, particle.size * 2, 2);
        ctx.fillRect(-1, -particle.size, 2, particle.size * 2);
      } else {
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
  }

  function drawMidgroundAtmosphere(now) {
    const shimmer = 0.018 + Math.sin(now * 0.0007) * 0.006;
    const haze = ctx.createLinearGradient(0, 80, 0, 520);
    haze.addColorStop(0, `rgba(214, 239, 239, ${0.13 + shimmer})`);
    haze.addColorStop(0.48, 'rgba(214, 239, 239, 0.035)');
    haze.addColorStop(1, 'rgba(214, 239, 239, 0)');
    ctx.save();
    ctx.fillStyle = haze;
    ctx.fillRect(0, 0, DESIGN_SIZE, 560);
    ctx.restore();
  }

  function flagMask(step) {
    return players.reduce((mask, player, index) => mask | (player.step >= step ? (1 << index) : 0), 0);
  }

  function drawCheckpointFlags() {
    const sheet = loadedAssets.flags;
    if (!sheet) return;
    const cellWidth = 256;
    const cellHeight = 384;
    for (let step = FLAG_INTERVAL; step <= TOTAL_STEPS; step += FLAG_INTERVAL) {
      const route = routePoint(step / TOTAL_STEPS, step % 10 === 0 ? -48 : 48);
      const mask = flagMask(step);
      const row = mask === 3 || mask === 5 || mask === 6 ? 1 : 0;
      const column = mask === 3 ? 0 : mask === 5 ? 1 : mask === 6 ? 2 : mask === 1 ? 0 : mask === 2 ? 1 : 2;
      const scale = perspectiveScale(route.y);
      const width = 58 * scale;
      const height = 86 * scale;
      ctx.save();
      ctx.globalAlpha = mask ? 1 : 0.38;
      ctx.filter = mask ? 'none' : 'grayscale(1)';
      ctx.drawImage(sheet, column * cellWidth, row * cellHeight, cellWidth, cellHeight, route.x - width / 2, route.y - height, width, height);
      ctx.restore();
    }
  }

  function drawRoomBadge(player, x, y, scale) {
    // Small part of the character identity, not a HUD element.
    const width = 30 * scale;
    const height = 18 * scale;
    const badgeX = x + 24 * scale;
    const badgeY = y - 72 * scale;
    ctx.save();
    ctx.fillStyle = '#151724';
    ctx.fillRect(badgeX - 2 * scale, badgeY - 2 * scale, width + 4 * scale, height + 4 * scale);
    ctx.fillStyle = '#f6d36b';
    ctx.fillRect(badgeX, badgeY, width, height);
    ctx.fillStyle = '#1b1b28';
    ctx.font = `bold ${Math.max(10, Math.round(16 * scale))}px monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(player.room, badgeX + width / 2, badgeY + height / 2 + 1 * scale);
    ctx.restore();
  }

  function drawSprite(player, point, now) {
    const sheet = loadedAssets[player.sheet];
    if (!sheet) return;
    let row = 0;
    let column = ((Math.floor(now / 260) % 4) + 4) % 4;
    let jump = 0;
    const moving = Boolean(player.moving);
    if (moving) {
      row = 2;
      column = Math.floor(player.moving.walkDistance / 5) % 4;
      jump = Math.sin(clamp(player.moving.elapsed / player.moving.duration, 0, 1) * Math.PI) * 24;
    } else if (player.celebrationUntil > now) {
      row = 3;
      column = Math.floor(now / 190) % 2;
      jump = Math.abs(Math.sin(now * 0.012)) * 5;
    } else if (player.reactionUntil > now) {
      row = 3;
      column = 2 + (Math.floor(now / 210) % 2);
      jump = Math.sin(now * 0.01) * 2;
    } else {
      row = 0;
      column = ((Math.floor(now / 340 + player.lane) % 4) + 4) % 4;
    }

    player.depth = point.depth;
    if (Math.abs(point.tangentX) < 0.18) player.facing = 'up';
    else player.facing = point.tangentX < 0 ? 'left' : 'right';
    const scale = racePerspectiveScale(point);
    const drawSize = (moving ? 98 : 90) * scale;
    const x = point.x - drawSize / 2;
    const footY = point.y;
    const y = footY - drawSize - jump * scale;
    const frameSize = 128;

    // Contact shadow is rendered immediately below the feet and follows perspective.
    ctx.save();
    ctx.globalAlpha = lerp(0.28, 0.52, depthRatio(point.depth));
    ctx.fillStyle = '#101522';
    ctx.beginPath();
    ctx.ellipse(point.x, footY + 4 * scale, 28 * scale, 10 * scale, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    if (player.facing === 'left') {
      ctx.translate(point.x, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(sheet, column * frameSize, row * frameSize, frameSize, frameSize, x - point.x, y, drawSize, drawSize);
    } else {
      ctx.drawImage(sheet, column * frameSize, row * frameSize, frameSize, frameSize, x, y, drawSize, drawSize);
    }
    ctx.restore();

    if (moving) {
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = '#f6d98b';
      for (let i = 0; i < 3; i += 1) ctx.fillRect(point.x + (i - 1) * 18 * scale, footY + 18 * scale + (i % 2) * 7 * scale, Math.max(2, 4 * scale), Math.max(2, 4 * scale));
      ctx.restore();
    }
  }

  function drawParticles() {
    particles.forEach((particle) => {
      ctx.save();
      ctx.globalAlpha = clamp(particle.life, 0, 1);
      ctx.fillStyle = particle.color;
      ctx.fillRect(Math.round(particle.x), Math.round(particle.y), particle.size, particle.size);
      ctx.restore();
    });
  }

  function ceremonySlot(rank) {
    return [
      { x: 512, y: 625, trophyY: 460, trophy: loadedAssets.trophyGold },
      { x: 350, y: 710, trophyY: 550, trophy: loadedAssets.trophySilver },
      { x: 680, y: 770, trophyY: 615, trophy: loadedAssets.trophyBronze }
    ][rank];
  }

  function drawCeremonyActor(player, rank, progress, now) {
    const sheet = loadedAssets[player.sheet];
    if (!sheet) return;
    const slot = ceremonySlot(rank);
    const entrance = easeInOut(clamp((progress - 0.08) / 0.38, 0, 1));
    const start = { x: 512 + player.lane * 2, y: 950 };
    const x = lerp(start.x, slot.x, entrance);
    const footY = lerp(start.y, slot.y, entrance);
    const arriving = entrance < 1;
    const row = arriving ? 1 : rank === 0 ? 3 : 2;
    const column = arriving ? Math.floor(now / 150) % 4 : Math.floor(now / (rank === 0 ? 180 : 220)) % 2;
    const size = rank === 0 ? 126 : 112;
    const bob = arriving ? Math.sin(entrance * Math.PI * 5) * 8 : Math.abs(Math.sin(now * 0.009 + rank)) * 5;
    ctx.save();
    ctx.globalAlpha = clamp((progress - 0.05) / 0.16, 0, 1);
    ctx.fillStyle = 'rgba(10, 12, 18, 0.42)';
    ctx.beginPath();
    ctx.ellipse(x, footY + 5, size * 0.28, size * 0.1, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.drawImage(sheet, column * 128, row * 128, 128, 128, x - size / 2, footY - size - bob, size, size);
    ctx.restore();
  }

  function drawCeremonyTrophy(rank, progress, now) {
    const slot = ceremonySlot(rank);
    const image = slot.trophy;
    if (!image) return;
    const pop = easeOutBack(clamp((progress - 0.42 - rank * 0.04) / 0.2, 0, 1));
    if (pop <= 0) return;
    const size = (rank === 0 ? 120 : 92) * pop;
    const floatY = slot.trophyY + Math.sin(now * 0.004 + rank) * 7;
    ctx.save();
    ctx.globalAlpha = clamp(pop, 0, 1);
    ctx.shadowColor = rank === 0 ? '#ffe37b' : rank === 1 ? '#dbe9ff' : '#e7a66c';
    ctx.shadowBlur = 18;
    ctx.drawImage(image, slot.x - size / 2, floatY - size / 2, size, size);
    ctx.restore();
  }

  function drawCeremonyFireworks(progress, now) {
    if (progress < 0.46) return;
    ctx.save();
    for (let burst = 0; burst < 4; burst += 1) {
      const cx = 180 + burst * 220;
      const cy = 180 + (burst % 2) * 90;
      const radius = 30 + ((now * 0.08 + burst * 37) % 80);
      ctx.globalAlpha = 0.18 + (Math.sin(now * 0.006 + burst) + 1) * 0.18;
      ctx.strokeStyle = ['#f6d36b', '#69d66b', '#ef6262', '#b9d6ff'][burst];
      ctx.lineWidth = 4;
      for (let ray = 0; ray < 10; ray += 1) {
        const angle = ray * Math.PI * 2 / 10;
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(angle) * radius * 0.35, cy + Math.sin(angle) * radius * 0.35);
        ctx.lineTo(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  function drawCeremonyConfetti() {
    ceremonyParticles.forEach((particle) => {
      ctx.save();
      ctx.translate(particle.x, particle.y);
      ctx.rotate(particle.spin);
      ctx.fillStyle = particle.color;
      ctx.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size * 0.6);
      ctx.restore();
    });
  }

  function drawCeremony(now) {
    const progress = clamp(elapsed(ceremonyStartedAt, now) / CEREMONY_DURATION, 0, 1);
    const podium = loadedAssets.podium;
    ctx.fillStyle = '#080d18';
    ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    if (podium) {
      const zoom = lerp(0.84, 1, easeInOut(clamp(progress / 0.25, 0, 1)));
      const size = DESIGN_SIZE * zoom;
      ctx.save();
      ctx.globalAlpha = clamp(progress / 0.2, 0, 1);
      ctx.drawImage(podium, (DESIGN_SIZE - size) / 2, (DESIGN_SIZE - size) / 2, size, size);
      ctx.restore();
    }
    const dark = 0.62 - clamp(progress / 0.25, 0, 1) * 0.25;
    ctx.fillStyle = `rgba(4, 8, 16, ${dark})`;
    ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    ceremonyOrder.forEach((player, rank) => drawCeremonyActor(player, rank, progress, now));
    ceremonyOrder.forEach((player, rank) => drawCeremonyTrophy(rank, progress, now));
    drawCeremonyFireworks(progress, now);
    drawCeremonyConfetti();
    ctx.save();
    ctx.fillStyle = '#fff1bd';
    ctx.textAlign = 'center';
    ctx.font = '700 38px monospace';
    ctx.shadowColor = '#15151e';
    ctx.shadowBlur = 8;
    ctx.fillText('CERIMÔNIA DE PREMIAÇÃO', DESIGN_SIZE / 2, 86);
    ctx.fillStyle = ceremonyOrder[0]?.tint || '#f6d36b';
    ctx.font = '700 26px monospace';
    ctx.fillText(`CAMPEÃ: SALA ${ceremonyOrder[0]?.room || ''}`, DESIGN_SIZE / 2, 124);
    ctx.fillStyle = 'rgba(5, 10, 17, 0.76)';
    ctx.fillRect(248, 954, 528, 42);
    ctx.fillStyle = '#fff1bd';
    ctx.font = '700 18px monospace';
    ctx.fillText("Aperte 'R' para reiniciar a gincana", DESIGN_SIZE / 2, 980);
    ctx.restore();
  }

  function drawVictory() {
    if (!winner) return;
    ctx.save();
    ctx.fillStyle = 'rgba(5, 12, 18, 0.68)';
    ctx.fillRect(150, 390, 724, 244);
    ctx.strokeStyle = winner.tint;
    ctx.lineWidth = 6;
    ctx.strokeRect(150, 390, 724, 244);
    ctx.fillStyle = '#fff2b8';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '700 42px monospace';
    ctx.fillText(`Sala ${winner.room} venceu!`, DESIGN_SIZE / 2, 500);
    ctx.fillStyle = winner.tint;
    ctx.font = '700 22px monospace';
    ctx.fillText('Pressione R para uma nova corrida', DESIGN_SIZE / 2, 560);
    ctx.restore();
  }

  function drawCutscene(now) {
    const sheet = loadedAssets.cutscene;
    ctx.fillStyle = '#07131c';
    ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    if (!sheet) return;
    const t = clamp(elapsed(cutsceneStartedAt, now) / CUTSCENE_DURATION, 0, 0.9999);
    const seconds = elapsed(cutsceneStartedAt, now) / 1000;
    const act = seconds < 3 ? 1 : seconds < 6 ? 2 : seconds < 8 ? 3 : 4;
    const local = act === 1 ? seconds / 3 : act === 2 ? (seconds - 3) / 3 : act === 3 ? (seconds - 6) / 2 : (seconds - 8) / 2;
    const easedLocal = easeInOutQuad(clamp(local, 0, 1));
    const frameFloat = act === 1 ? easedLocal * 2.0 : act === 2 ? 3 + easedLocal * 2.0 : act === 3 ? 6 + easedLocal * 1.0 : 7.5 + easedLocal * 0.5;
    const frame = Math.min(8, Math.floor(frameFloat));
    const nextFrame = Math.min(8, frame + 1);
    const blend = frame === 8 ? 0 : clamp((frameFloat - frame) * 0.28, 0, 0.28);
    const zoom = act === 1 ? lerp(1.18, 1.0, easedLocal) : act === 2 ? lerp(1.0, 1.12, easedLocal) : act === 3 ? lerp(1.08, 1.28, easeOutBack(easedLocal)) : lerp(1.12, 0.96, easedLocal);
    const panX = act === 1 ? lerp(-34, 34, easedLocal) : act === 2 ? lerp(-44, 44, easedLocal) : act === 4 ? lerp(0, -12, easedLocal) : 0;
    const rotation = act === 2 ? Math.sin(easedLocal * Math.PI) * 0.012 : act === 3 ? Math.sin(easedLocal * Math.PI) * 0.018 : 0;
    const shake = act === 3 ? (1 - Math.abs(easedLocal - 0.5) * 2) * 14 : 0;
    const shakeX = shake * Math.sin(now * 0.055);
    const shakeY = shake * Math.cos(now * 0.061);
    const cellSize = 512;
    const drawFrame = (frameIndex, alpha = 1) => {
      const sourceX = (frameIndex % 3) * cellSize;
      const sourceY = Math.floor(frameIndex / 3) * cellSize;
      const destinationSize = DESIGN_SIZE * zoom;
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(DESIGN_SIZE / 2 + panX + shakeX, DESIGN_SIZE / 2 + shakeY);
      ctx.rotate(rotation);
      ctx.drawImage(sheet, sourceX, sourceY, cellSize, cellSize, -destinationSize / 2, -destinationSize / 2, destinationSize, destinationSize);
      ctx.restore();
    };
    drawFrame(frame);
    if (blend > 0) drawFrame(nextFrame, blend);
    if (act === 3) drawVersus(now, easedLocal);
    drawCutsceneSparks(now, t, act, local);
    drawSpeedLines(now, act, local);
    if (act === 3 && local > 0.28) {
      const flash = clamp((local - 0.28) / 0.15, 0, 1) * clamp((1 - local) / 0.32, 0, 1);
      ctx.fillStyle = `rgba(255, 250, 218, ${flash * 0.92})`;
      ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    }
    // Cinematic letterbox bars keep the cutscene readable on any monitor ratio.
    ctx.fillStyle = 'rgba(3, 9, 14, 0.82)';
    ctx.fillRect(0, 0, DESIGN_SIZE, 72);
    ctx.fillRect(0, DESIGN_SIZE - 72, DESIGN_SIZE, 72);
    if (act === 4) {
      const fade = clamp((local - 0.46) / 0.54, 0, 1);
      ctx.fillStyle = `rgba(3, 9, 14, ${fade * 0.82})`;
      ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    }
  }

  function drawVersus(now, progress) {
    const pulse = 1 + Math.sin(now * 0.012) * 0.08;
    ctx.save();
    ctx.translate(DESIGN_SIZE / 2, 512);
    ctx.scale(pulse, pulse);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '900 112px monospace';
    ctx.lineWidth = 12;
    ctx.strokeStyle = '#180e2d';
    ctx.strokeText('VS', 0, 0);
    ctx.fillStyle = progress > 0.72 ? '#fff7cf' : '#ffcf62';
    ctx.fillText('VS', 0, 0);
    ctx.restore();
  }

  function drawCutsceneSparks(now, progress, act, local) {
    const intensity = act === 3 ? 0.75 + Math.sin(local * Math.PI) * 0.25 : act === 2 ? 0.24 + local * 0.22 : 0.12 + Math.sin(progress * Math.PI) * 0.16;
    ctx.save();
    ctx.translate(DESIGN_SIZE / 2, 512);
    ctx.globalAlpha = intensity;
    ctx.fillStyle = '#ffe07a';
    for (let i = 0; i < 18; i += 1) {
      const angle = (Math.PI * 2 * i) / 12 + now * 0.0008;
      const radius = 28 + Math.sin(now * 0.004 + i) * 10 + intensity * 52;
      const size = i % 3 === 0 ? 6 : 3;
      ctx.fillRect(Math.round(Math.cos(angle) * radius), Math.round(Math.sin(angle) * radius), size, size);
    }
    ctx.restore();
  }

  function drawSpeedLines(now, act, local) {
    if (act === 1) return;
    const alpha = act === 3 ? 0.28 + local * 0.28 : act === 2 ? 0.08 + local * 0.13 : 0.12 + local * 0.18;
    ctx.save();
    ctx.translate(DESIGN_SIZE / 2, DESIGN_SIZE / 2);
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = act === 3 ? '#ffdc79' : '#b6edff';
    ctx.lineWidth = 5;
    for (let i = 0; i < 14; i += 1) {
      const angle = (Math.PI * 2 * i) / 14 + now * 0.0004;
      const inner = 180 + (i % 3) * 22;
      const outer = 430 + (i % 4) * 34;
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * inner, Math.sin(angle) * inner);
      ctx.lineTo(Math.cos(angle) * outer, Math.sin(angle) * outer);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawScoreIcon(x, y, color, kind) {
    ctx.save();
    ctx.fillStyle = '#17151b';
    ctx.fillRect(x - 2, y - 2, 28, 28);
    ctx.fillStyle = color;
    if (kind === 'slime') {
      ctx.beginPath();
      ctx.arc(x + 12, y + 13, 10, Math.PI, 0);
      ctx.lineTo(x + 22, y + 18);
      ctx.lineTo(x + 2, y + 18);
      ctx.closePath();
      ctx.fill();
    } else if (kind === 'ghost') {
      ctx.beginPath();
      ctx.arc(x + 12, y + 11, 9, Math.PI, 0);
      ctx.lineTo(x + 21, y + 20);
      ctx.lineTo(x + 16, y + 17);
      ctx.lineTo(x + 12, y + 21);
      ctx.lineTo(x + 8, y + 17);
      ctx.lineTo(x + 3, y + 20);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillRect(x + 4, y + 4, 16, 16);
      ctx.fillStyle = '#fff1b0';
      ctx.fillRect(x + 7, y + 9, 3, 4);
      ctx.fillRect(x + 14, y + 9, 3, 4);
    }
    ctx.restore();
  }

  function drawMiniScoreboard() {
    const x = 20;
    const y = 20;
    const width = 232;
    const height = 132;
    const rows = [
      { room: '2A', score: pontos_2A, color: '#4b9cff', kind: 'skeleton' },
      { room: '2B', score: pontos_2B, color: '#ef6262', kind: 'ghost' },
      { room: '2C', score: pontos_2C, color: '#69d66b', kind: 'slime' }
    ];
    ctx.save();
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = '#231d1b';
    ctx.fillRect(x + 6, y + 6, width - 12, height - 12);
    ctx.fillStyle = '#5c3b29';
    ctx.fillRect(x + 4, y, width - 8, 4);
    ctx.fillRect(x + 4, y + height - 4, width - 8, 4);
    ctx.fillRect(x, y + 4, 4, height - 8);
    ctx.fillRect(x + width - 4, y + 4, 4, height - 8);
    ctx.fillStyle = '#9a6a43';
    ctx.fillRect(x + 10, y + 8, width - 20, 2);
    ctx.fillRect(x + 10, y + height - 10, width - 20, 2);
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(255, 226, 157, 0.08)';
    for (let i = 0; i < 5; i += 1) ctx.fillRect(x + 18 + i * 42, y + 12 + (i % 2) * 8, 22, 2);
    rows.forEach((row, index) => {
      const rowY = y + 18 + index * 36;
      drawScoreIcon(x + 14, rowY + 2, row.color, row.kind);
      ctx.fillStyle = '#fff0bd';
      ctx.font = '700 22px monospace';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(row.room, x + 52, rowY + 14);
      ctx.fillStyle = row.color;
      ctx.font = '700 24px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(String(row.score).padStart(2, '0'), x + width - 18, rowY + 14);
    });
    ctx.restore();
  }

  function render(now) {
    if (phase === 'cutscene') {
      drawCutscene(now);
      return;
    }
    if (phase === 'ceremony') {
      drawCeremony(now);
      return;
    }
    // Exact 2.5D order: background, midground, depth-sorted actors, foreground.
    // The camera transform affects the world only; the scoreboard remains screen-fixed.
    ctx.fillStyle = '#07131c';
    ctx.fillRect(0, 0, DESIGN_SIZE, DESIGN_SIZE);
    drawAnimatedBackground(now);
    ctx.save();
    cameraTransform(now);
    drawAnimatedMidground(now);
    drawMidgroundAtmosphere(now);
    drawCheckpointFlags();

    const depthSortedPlayers = players
      .map((player) => ({ player, point: currentPosition(player) }))
      .sort((a, b) => a.point.depth - b.point.depth);
    depthSortedPlayers.forEach(({ player, point }) => drawSprite(player, point, now));
    drawParticles();

    // The transparent foreground is a precomposed set of near-camera objects;
    // drawing it last makes its lower-edge foliage occlude deeper actors.
    drawAnimatedForeground(now);
    drawAmbientParticles(now);
    ctx.restore();
    drawMiniScoreboard();
    drawVictory();
  }

  function loop(now) {
    update(now);
    render(now);
    requestAnimationFrame(loop);
  }

  async function init() {
    loadedAssets = await loadAssets();
    ready = true;
    requestAnimationFrame(loop);
  }

  startButton.addEventListener('click', beginPresentation);
  window.addEventListener('keydown', handleKeyDown, { passive: false });
  init().catch((error) => console.error(error));
})();
